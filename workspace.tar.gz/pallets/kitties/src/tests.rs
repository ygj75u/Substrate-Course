use crate::{Event, Error, mock::*};
use frame_support::{assert_noop, assert_ok, traits::{OnFinalize, OnInitialize}};

fn run_to_block( n: u64) {
	while System::block_number() < n {
		KittiesModule::on_finalize(System::block_number());
		System::on_finalize(System::block_number());
		System::set_block_number(System::block_number()+1);
		System::on_initialize(System::block_number());
		KittiesModule::on_initialize(System::block_number());
	}
}


#[test]
fn create_kitty_works(){
	new_test_ext().execute_with(|| {
		run_to_block(10);
		assert_ok!(KittiesModule::create( Origin::signed(1)) );

		assert_eq!(
			System::events()[1].event,
			TestEvent::kitties( Event::<Test>::Created( 1u64 , 0) )
		);
	})
}

// 质押钱不够，创建小猫失败
#[test]
fn create_kitty_failed_when_not_enough_money(){
	new_test_ext().execute_with(|| {
		run_to_block(10);
		assert_noop!(KittiesModule::create( Origin::signed(9)) , Error::<Test>::MoneyNotEnough);
	})
}


#[test]
fn transfer_kitty_works(){
	new_test_ext().execute_with(|| {
		run_to_block(10);
		let _ = KittiesModule::create( Origin::signed(1) );

		assert_ok!(KittiesModule::transfer( Origin::signed(1), 2, 0 ) );

		assert_eq!(
			System::events()[4].event,
			TestEvent::kitties( Event::<Test>::Transferred( 1u64 ,2u64, 0) )
		);
	});
}

// 小猫不存在，转让失败
#[test]
fn transfer_kitty_failed_when_not_exists(){
	new_test_ext().execute_with(|| {
		assert_noop!(KittiesModule::transfer( Origin::signed(1), 2, 0 ) , Error::<Test>::KittyNotExists);
	})
}

// 不是小猫的主人，转让失败
#[test]
fn transfer_kitty_failed_when_not_owner(){
	new_test_ext().execute_with(|| {
		run_to_block(10);
		let _ = KittiesModule::create( Origin::signed(1) );

		assert_noop!(KittiesModule::transfer( Origin::signed(2), 3, 0 ) , Error::<Test>::NotKittyOwner);
	})
}

// 不能转让小猫给自己，转让失败
#[test]
fn transfer_kitty_failed_when_transfer_self(){
	new_test_ext().execute_with(|| {
		run_to_block(10);
		let _ = KittiesModule::create( Origin::signed(1) );

		assert_noop!(KittiesModule::transfer( Origin::signed(1), 1, 0 ) , Error::<Test>::TransferToSelf);
	})
}

#[test]
fn breed_kitty_work(){
	new_test_ext().execute_with(|| {
		run_to_block(10);
		let _ = KittiesModule::create( Origin::signed(1）);
		let _ = KittiesModule::create( Origin::signed(1) );

		assert_ok!( KittiesModule::breed( Origin::signed(1), 0, 1 ) );

		assert_eq!(
			System::events()[1].event,
			TestEvent::kitties( Event::<Test>::Created( 1u64, 0) )
		);
	});
}

// 同一个猫，繁殖失败
#[test]
fn breed_kitty_fail_when_same(){
	new_test_ext().execute_with(|| {
		run_to_block(10);
		let _ = KittiesModule::create( Origin::signed(1) );

		assert_noop!( KittiesModule::breed( Origin::signed(1), 0, 0 ) , Error::<Test>::RequiredDiffrentParent);
	})
}

// 猫不存在,繁殖失败
#[test]
fn breed_kitty_fail_when_not_exists(){
	new_test_ext().execute_with(|| {
		assert_noop!( KittiesModule::breed( Origin::signed(1), 0, 1 ) , Error::<Test>::KittyNotExists);
	})
}

// 因为不是猫的主人，繁殖失败
#[test]
fn breed_kitty_fail_when_(){
	new_test_ext().execute_with(|| {
		run_to_block(10);
		let _ = KittiesModule::create( Origin::signed(1) );
		let _ = KittiesModule::create( Origin::signed(1) );

		assert_noop!( KittiesModule::breed( Origin::signed(2), 0, 1) , Error::<Test>::NotKittyOwner);
	}


